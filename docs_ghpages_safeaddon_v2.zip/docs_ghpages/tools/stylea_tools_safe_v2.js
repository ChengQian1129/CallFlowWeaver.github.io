/*!
 * stylea_tools_safe_v2.js
 * Visible, opt-in, and diagnosable add-on for Style A.
 * - Floating "Style A" button with panel.
 * - Status line shows: APIs detected + Flow counts.
 * - Optional "Default StyleA" toggle (OFF by default). When ON, softly delegates Preview only if flow exists.
 * - No canvas mutations. Preview via hash with {nodes,messages}.
 */
(function(){
  'use strict';
  var NS='[stylea-safe v2]';
  function log(){ try{ console.log.apply(console,[NS].concat([].slice.call(arguments))); }catch(e){} }

  if (window.__stylea_safe_v2__) return; window.__stylea_safe_v2__=true;

  // --- Data helpers ---
  function detectApis(){
    return {
      hasGetFlow: typeof window.getFlow === 'function',
      hasLanes: typeof window.lanes === 'function',
      hasExportMessages: Array.isArray(window.exportMessages)
    };
  }
  function buildFlowFromGlobals(){
    try{
      var lanesFn = (typeof window.lanes==='function') ? window.lanes : null;
      var lanesArr = lanesFn ? (lanesFn()||[]) : [];
      var raw = Array.isArray(window.exportMessages) ? window.exportMessages : [];
      var messages = (raw||[]).map(function(m,i){
        var h=(m&&m.info&&m.info.header)||{};
        var proto=h.protocol||m.protocol||'';
        var iface=h.interface||'';
        var release=h.release||m.release||'';
        var id=h.id||m.id||'';
        var msgName=h.msg||m.message||'';
        var label=m.label||((i+1)+' '+(msgName||'Message'));
        return {from:m.from,to:m.to,label,info:{header:{msg:msgName,protocol:proto,interface:iface,release,id},payload:(m.info&&m.info.payload)||{}}};
      });
      var nodes = (lanesArr||[]).map(function(n){
        return {id:(n.id||n.name||('node'+Math.random().toString(36).slice(2,8))),name:n.name||n.id||'node',type:n.type||'N/A'};
      });
      if (!nodes.length || !messages.length) return null;
      return {nodes:nodes, messages:messages};
    }catch(e){ return null; }
  }
  function computeFlow(){
    try{
      if (typeof window.getFlow==='function'){
        var f = window.getFlow();
        if (f && Array.isArray(f.nodes) && f.nodes.length && Array.isArray(f.messages) && f.messages.length) return f;
      }
      return buildFlowFromGlobals();
    }catch(e){ return null; }
  }

  // --- UI (Shadow DOM) ---
  var host=document.createElement('div');
  host.id='stylea-safe-v2-host';
  host.style.cssText='position:fixed;right:14px;bottom:14px;z-index:2147483647';
  document.documentElement.appendChild(host);
  var root=host.attachShadow({mode:'open'});
  root.innerHTML=`
    <style>
      :host { all: initial; }
      .btn { all: initial; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; font-size:12px;
             padding:6px 10px; border-radius:10px; border:1px solid rgba(0,0,0,.12);
             background:#fff; color:#111; cursor:pointer; box-shadow:0 6px 24px rgba(0,0,0,.12); }
      .btn[disabled]{ opacity:.5; cursor:not-allowed; }
      .toggle { display:inline-flex; align-items:center; gap:6px; }
      .chip { display:inline-block; font-size:11px; padding:2px 6px; border-radius:999px; background:#f3f3f3; color:#333; border:1px solid rgba(0,0,0,.08) }
      .fab { position:relative; }
      .fab>.btn { font-size:13px; padding:8px 12px; }
      .panel { position:absolute; bottom:42px; right:0; display:none; background:#fff; border:1px solid rgba(0,0,0,.1);
               border-radius:12px; box-shadow:0 8px 28px rgba(0,0,0,.18); padding:10px; gap:8px; width:max-content; }
      .panel.show{ display:block; }
      .row{ display:flex; gap:8px; margin-bottom:8px; }
      .muted{ font-size:11px; color:#666; }
      .toast{ position:fixed; right:0; top:0; display:flex; flex-direction:column; gap:8px; }
      .toast>div{ background:rgba(0,0,0,.82); color:#fff; padding:8px 12px; border-radius:10px; margin:12px; font-size:12px;
                  box-shadow:0 6px 24px rgba(0,0,0,.3); }
      .switch{ position:relative; width:36px; height:20px; border-radius:999px; background:#ddd; vertical-align:middle; transition:all .2s ease; display:inline-block; }
      .switch[data-on="1"]{ background:#4ade80; }
      .knob{ position:absolute; top:2px; left:2px; width:16px; height:16px; border-radius:50%; background:#fff; transition:left .2s ease; box-shadow:0 1px 4px rgba(0,0,0,.2); }
      .switch[data-on="1"] .knob{ left:18px; }
    </style>
    <div class="toast" id="t"></div>
    <div class="fab">
      <button id="toggle" class="btn" title="Style A 工具">Style A</button>
      <div class="panel" id="panel">
        <div class="row">
          <button id="btnPreview" class="btn" title="打开 Style A 预览">Preview</button>
          <button id="btnExport" class="btn" title="导出 {nodes,messages} 为 JSON">Export JSON</button>
          <button id="btnImport" class="btn" title="导入 JSON 并打开 Style A 预览">Import JSON</button>
        </div>
        <div class="row muted" id="status">Flow: detecting…</div>
        <div class="row">
          <div class="toggle">
            <span class="muted">Default StyleA</span>
            <div id="sw" class="switch" data-on="0"><div class="knob"></div></div>
          </div>
          <span class="chip" id="apis">APIs: –</span>
        </div>
      </div>
    </div>
  `;

  function qs(id){ return root.getElementById(id); }
  function toast(msg){
    try{
      var box=qs('t'); var d=document.createElement('div'); d.textContent=msg;
      box.appendChild(d); setTimeout(function(){ d.style.transition='opacity .25s'; d.style.opacity='0'; }, 1800);
      setTimeout(function(){ d.remove(); }, 2200);
    }catch(e){}
  }

  // Panel toggle
  var panel=qs('panel');
  qs('toggle').addEventListener('click', function(){ panel.classList.toggle('show'); refresh(); });

  // Buttons
  qs('btnPreview').addEventListener('click', function(e){ e.preventDefault(); preview(); });
  qs('btnExport').addEventListener('click', function(e){ e.preventDefault(); exportJSON(); });
  qs('btnImport').addEventListener('click', function(e){ e.preventDefault(); importJSON(); });

  function setDisabled(el, disabled){ el.toggleAttribute('disabled', !!disabled); }

  function refresh(){
    var apis=detectApis();
    var f=computeFlow();
    setDisabled(qs('btnPreview'), !f);
    setDisabled(qs('btnExport'), !f);
    qs('status').textContent = f ? ('Flow: '+(f.nodes.length||0)+' nodes · '+(f.messages.length||0)+' messages') : 'Flow: not detected';
    qs('apis').textContent = 'APIs: ' + (apis.hasGetFlow?'getFlow ':'') + (apis.hasLanes?'lanes ':'') + (apis.hasExportMessages?'exportMessages':'').trim() || '–';
    // update switch visual
    var on = localStorage.getItem('stylea_default_preview') === '1';
    qs('sw').setAttribute('data-on', on ? '1':'0');
  }

  // Preview / Export / Import
  function openStyleAPreview(flow){
    var f = flow || computeFlow();
    if(!f){ toast('暂无可预览的流程。'); return; }
    var url = './preview/styleA_pure.html#' + encodeURIComponent(JSON.stringify(f));
    window.open(url, '_blank');
  }
  function preview(){ openStyleAPreview(null); }
  function exportJSON(){
    var f=computeFlow();
    if(!f){ toast('暂无流程可导出。'); return; }
    var json=JSON.stringify(f,null,2);
    try{
      var blob=new Blob([json],{type:'application/json'});
      var url=URL.createObjectURL(blob);
      var a=document.createElement('a'); a.href=url; a.download='flow_export.json';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function(){ URL.revokeObjectURL(url); }, 20000);
    }catch(e){}
    if (navigator.clipboard) navigator.clipboard.writeText(json).catch(function(){});
    toast('已导出 flow_export.json，并复制到剪贴板。');
  }
  function importJSON(){
    var text=prompt('粘贴 {nodes, messages} JSON：');
    if(!text) return;
    try{
      var obj=JSON.parse(text);
      if(!obj || !Array.isArray(obj.nodes) || !Array.isArray(obj.messages)) throw new Error('需要 {nodes, messages}');
      openStyleAPreview(obj);
      toast('已用导入数据打开 Style A 预览（不修改画布）。');
    }catch(e){ toast('导入失败：'+(e&&e.message)); }
  }

  // Default StyleA switch (OFF by default)
  function onDelegation(e){
    try{
      var el = e.target && (e.target.closest('button') || e.target.closest('a'));
      if(!el) return;
      // If user uses modifier keys, respect original behavior
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      // Heuristic match
      var t=(el.textContent||'').toLowerCase();
      var aria=(el.getAttribute&& (el.getAttribute('aria-label')||'')).toLowerCase();
      var title=(el.getAttribute&& (el.getAttribute('title')||'')).toLowerCase();
      var looksPreview = /open\s*preview|预览/.test(t) || /download\s*html|导出\s*html/.test(t) ||
                         /open\s*preview|download\s*html/.test(aria) || /preview|html/.test(title);
      if (!looksPreview) return;
      // Only intercept when flow exists
      if (!computeFlow()) return;
      e.preventDefault();
      preview();
    }catch(err){}
  }

  var sw=qs('sw');
  sw.addEventListener('click', function(){
    var cur = localStorage.getItem('stylea_default_preview') === '1';
    var next = !cur;
    localStorage.setItem('stylea_default_preview', next ? '1':'0');
    // toggle delegation
    try{
      document.removeEventListener('click', onDelegation, true);
      if (next) document.addEventListener('click', onDelegation, true);
    }catch(e){}
    qs('sw').setAttribute('data-on', next ? '1':'0');
    toast(next ? 'Default StyleA：ON' : 'Default StyleA：OFF');
  });

  // initialize delegation from stored pref
  try{
    var on = localStorage.getItem('stylea_default_preview') === '1';
    if (on) document.addEventListener('click', onDelegation, true);
  }catch(e){}

  // first paint
  setTimeout(refresh, 200);
  log('Loaded.');
})();