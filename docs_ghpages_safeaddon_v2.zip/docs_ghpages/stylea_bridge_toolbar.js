/* Style A toolbar bridge: adds a visible button into the "Open Preview / Download HTML" toolbar,
   and wires it to send the current flow to preview/styleA_pure.html */
(function(){
  'use strict';

  function inferInterface(proto){
    switch((proto||'').toUpperCase()){
      case 'NGAP':return 'N2'; case 'PFCP':return 'N4'; case 'NAS-5G':return 'N1'; case 'RRC':return 'Uu'; case 'HTTP/SBI':return 'Nn'; default:return '';
    }
  }
  function sliceBracketed(text, startIdx){
    const i0 = text.indexOf('[', startIdx); if(i0<0) return null;
    let i=i0, d=0, inStr=false, q='', esc=false;
    for(; i<text.length; i++){
      const ch=text[i];
      if(inStr){
        if(esc){esc=false; continue;}
        if(ch==="'" && q==="'") inStr=false;
        else if(ch==='"' && q=== '"') inStr=false;
        else if(ch==='\\') esc=true;
      }else{
        if(ch==="'"||ch=== '"'){inStr=true; q=ch;}
        else if(ch==='[') d++;
        else if(ch===']'){ if(--d===0) return text.slice(i0, i+1); }
      }
    }
    return null;
  }
  function evalArray(snippet){ return (new Function('return ('+snippet+');'))(); }
  function getExportText(){
    const label = Array.from(document.querySelectorAll('div,span,h2,h3'))
      .find(el => /Preview\s+export\s*\(const\s+nodes\/messages\)/i.test(el.textContent||''));
    const ta = label ? (label.closest('div')||document.body).querySelector('textarea,pre,code') : null;
    return (ta && (ta.value || ta.textContent)) || '';
  }
  function flowFromTextarea(){
    try{
      const txt = getExportText();
      const nx = txt.indexOf('const nodes'), mx = txt.indexOf('const messages');
      if(nx<0 || mx<0) return null;
      const nodes = evalArray(sliceBracketed(txt, nx));
      const msgRaw = evalArray(sliceBracketed(txt, mx));
      const messages = (msgRaw||[]).map((m,i)=>{
        const h=(m&&m.info&&m.info.header)||m.header||{};
        const proto=h.protocol||m.protocol||'';
        const iface=h.interface||inferInterface(proto);
        const release=h.release||m.release||'';
        const id=h.id||m.id||'';
        const msgName=h.msg||m.message||'';
        const label=m.label||((i+1)+' '+(msgName||'Message'));
        return {from:m.from,to:m.to,label,
          info:{header:{msg:msgName,protocol:proto,interface:iface,release,id},payload:(m.info&&m.info.payload)||m.payload||{}},
          comment:m.comment||(m.info&&m.info.doc&&m.info.doc.comment_md)||''};
      });
      const set=new Set(Array.isArray(nodes)?nodes:[]);
      messages.forEach(mm=>{ if(mm.from) set.add(mm.from); if(mm.to) set.add(mm.to); });
      return {nodes:Array.from(set), messages};
    }catch(e){ return null; }
  }
  function flowFromGlobals(){
    const lanes = (typeof window.lanes==='function') ? (window.lanes()||[]) : [];
    const raw = Array.isArray(window.exportMessages) ? window.exportMessages : [];
    const messages = (raw||[]).map((m,i)=>{
      const h=(m&&m.info&&m.info.header)||{};
      const proto=h.protocol||m.protocol||'';
      const iface=h.interface||inferInterface(proto);
      const release=h.release||m.release||'';
      const id=h.id||m.id||'';
      const msgName=h.msg||m.message||'';
      const label=m.label||((i+1)+' '+(msgName||'Message'));
      return {from:m.from,to:m.to,label,
        info:{header:{msg:msgName,protocol:proto,interface:iface,release,id},payload:(m.info&&m.info.payload)||{}},
        comment:(m.info&&m.info.doc&&m.info.doc.comment_md)||''};
    });
    const set=new Set(lanes); messages.forEach(mm=>{ if(mm.from) set.add(mm.from); if(mm.to) set.add(mm.to); });
    return {nodes:Array.from(set), messages};
  }
  function getFlow(){ return flowFromTextarea() || flowFromGlobals(); }

  function openStyleAPreview(){
    const flow = getFlow();
    if(!flow || !Array.isArray(flow.nodes) || !flow.nodes.length || !Array.isArray(flow.messages) || !flow.messages.length){
      alert('未检测到可预览的 nodes/messages'); return;
    }
    const url = './preview/styleA_pure.html#' + encodeURIComponent(JSON.stringify(flow));
    window.open(url, '_blank');
  }

  function injectButton(){
    // 找到“Open Preview / Download HTML”那组按钮容器
    const btns = Array.from(document.querySelectorAll('button'));
    const hostBtn = btns.find(b => /Open\s+Preview/i.test(b.textContent||''));
    if(!hostBtn) return false;
    const btn = hostBtn.cloneNode(true);
    btn.textContent = 'StyleA Preview (iframe)';
    btn.title = '按当前导出的 nodes/messages 在新窗口打开 StyleA 预览';
    btn.addEventListener('click', openStyleAPreview);
    hostBtn.parentNode.insertBefore(btn, hostBtn.nextSibling);
    return true;
  }

  function injectFallback(){
    if(document.getElementById('stylea-fixed')) return;
    const el = document.createElement('button');
    el.id = 'stylea-fixed';
    el.textContent = 'StyleA Preview';
    el.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483602;background:#111827;color:#fff;border:none;border-radius:999px;padding:10px 14px;font-size:13px;box-shadow:0 10px 30px rgba(0,0,0,.3);cursor:pointer';
    el.addEventListener('click', openStyleAPreview);
    document.body.appendChild(el);
  }

  function boot(){
    if (injectButton()) return;
    injectFallback();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  setTimeout(boot, 800);
  setTimeout(boot, 1800);
  window.addEventListener('keydown', (e)=>{
    if ((e.ctrlKey||e.metaKey) && e.altKey && e.key.toLowerCase()==='p'){ e.preventDefault(); openStyleAPreview(); }
  });
})();
